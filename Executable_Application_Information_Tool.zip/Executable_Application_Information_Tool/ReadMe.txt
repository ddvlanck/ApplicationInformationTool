Make sure the REST server is running (project AIT-REST-maven).

Double click the launcher.